# Game design and notecharting

This is completely unrelated from really audio latency related or Native Audio. But I guess for the sake of completeness of this section..

First and foremost this should come from your experience as a music gamer. Actually play the game and try to get good, play a lot of popular games that were done right and learn why they are fun. It ties to the game design as well so it may or may not apply to your game.

## Design affects pattern readability

Pay attention to game design because it affects how fun the pattern could be played.

- Why Superbeat Xonic is not as fun as maimai? Did you notice that fading out the note from inside out is much more distracting than maimai's "popup while not moving yet"?
- What would happen if maimai requires you to drag instantly instead of a beat later? 
- Why you could see the "horizon" in SDVX/Arcaea/Museca but not in Chunithm where it uses the UI as the horizon instead and used higher perspective view? What would happen if the game draw infinitely inside the screen instead of a much shallower sharp cut?
- What would happen if Lanota removed that center overlay and make it comes out from nothing?
- Why players uses Sudden intentionally in IIDX or DDR to have easier time in some sections?
- Why the "shutter" note in Jubeat is the easiest to read?
- Why Idolmaster has a slightly curved up note that benefits the reading while NeonFM looks messy?
- Why DDR feels snappy, harsh, and accurate while Pump It Up feels lenient and forgiving?
- What did you feel from seeing the note bomb effect of DDR compared to Pump It Up?
- Why the unique "W" lane in Museca that is reflecting the controller perfectly, is doing more harm than good in reading that they have to make it straight later?
- What Cytus, a Technika derivative, do to alleviate the read-ahead problem when you no longer have the incoming half to prepare?
- What would happen if a note tail in Project Diva is removed and it is just the symbol? Why the note tail disappeared suddenly on hit instead of a more graceful presentation?
- What is the benefit of bomb effect that zooms through the opposite direction of a note instead of staying still where you hit the note, an innovation by Chunithm's air note that Wacca eventually copied?
- In Jubeat, the note is coming from the inside so it is impossible to place jackhammers without being awkward to read, while vertical/perspective scrolling game is perfectly fine to do jackhammers. What would you do to Jubeat's design if you want to make jackhammer pattern viable? On the other hand, have you considered "banning" some patterns in your own game because it cannot work well enough?

Here are my tips. Most of the reading problems came from how you can relate one note to the other, and remaining problems are how notes enter the screen (suddenly? fading? scaling? how early?). It is difficult to tell which notes come at the same time in Jubeat more than vertical scrolling game, and easier still if they happen to be adjacent in cell to each other. However, what's even more difficult is in multidirection scrolling games like maimai or Superbeat Xonic where the opposing side may forms a double note. And there are more notes on the screen at a given time for you to "figure out" than Jubeat.

You may use visual aid like yellow color in maimai for doubles. Or color coded beats like DDR, Tone Sphere where you can read the beat far ahead, relaxing the brain from having to relate note positions. Some games employed both doubles indicator and color coded beat.

You can also use pattern design to help in note reading. Like you could gradually prepare player from closely relatable double notes, and take it from there, instead of starting from hard to read patterns. (See a song Mythos in maimai, for example. A close notes that leads to wide spin is fine. But it is not fine to start from wide doubles unless it is early in the song with less notes.) maimai is circular so they could do this, while Superbeat Xonic could not follow since there is no "bridge" that connect each sides. If you feel that your game is in a similar situation, maybe you should redesign it first before trying to find a pattern or add a new visual cues, which may not work out in the end. Maybe it is impossible by design. Prototype a lot, and harshly. (Demolish things that doesn't work without mercy) Don't go to the next phase until you can create a fun patterns from your design.

You maybe thinking of some excuses like : "Dammit, why is this not working like *that less-innovative game*? If we could get tons of OP composers like them...". A developer being in competitive spirit is always nice for music games community, but it maybe the case that you are not seeing innovations in those games.

You can't simply think that because most games scroll top to bottom, therefore you make it more innovative by doing perspective scroll. If that game is perspective scroll with note sprite, then you make more innovative by making the note a real 3D object. You must rethink did you introduces any other problems that didn't exist in that "less innovative" design and solve it accordingly.

## Long notes and doubles

Something that apply to generally all games, is when to use double/multiple notes at the same time.

Traditionally games are keysounded so doubles only appears when there are 2 sounds overlapping. That may be technically correct but not necessarily fun, because too many polyrhythms may confuse players. Nowadays doubles are used more expressively to highlight things. Cymbals are very commonly a double despite the drummer uses only one hand to hit one cymbal, for example. A piano chord may naturally be charted as 3-note chord, if your game allow. Polyrhythm works better when you have a 4-to-the-floor kick drum going on with something else like a lead synth that is relatively longnote-ish.

Beware of long note syndrome where you ended up charting everything as long notes. "But this is a vocal, and that is a long-ey synth! It's a blasphemy to chart those to anything *but* long notes!" The same apply as doubles/chords syndrome where you think each sound you hear is quite heavy and therefore you think they are justified to be an epic doubles. In the end, the chart ended up a chordsmashing mess. It dilute the effect of long note or doubles and make the chart bland. When you falls into this, the chart is said to went "rainbow" because you decorate everything according to the rule too correctly. And that is not necessarily a good thing.

It is fine to try "dry" charts and let the player "feel it" instead of cluttering the chart. You don't have to be overly worry if the player don't know which note is for which sound. Especially for non-keysounded game, use expressiveness to counter this. See DDR, there are many silent or made-up beats that works. Or Chunithm/Arcaea, where there is a kind of note that require movement but not a button press, you will see seemingly "random" sliding movement that goes to nothing, but they works when you play it. See the song Bird Sprite in Chunithm for an example of expressive, subjectivemania charting.

## Accuracy vs. fun

Some music gamers are quite extremist, often criticize "these notes aren't even going according to the song!" or "those are obviously 24th stream, why are they 16th here? Shitty chart!" without second thought about what if they were charted accurately, would it be as fun?

One thing to realize is that there are sounds that is a banger to listen to, but awkward to play in a music game. Often, these are sparse 16th notes without any leading 8th note or 4th note before them. They are often vocal syllable, but sometimes could be synth.

You must try to feel the **drop in norinori-ness** for the lack of better terms. When listening to these kind of song normally you may find yourself bopping head and have no problem at all, but awkward when actually play along the notes in games. The core reason is that your mind generates an imaginary beat to fill in the void when listening allowing you to have fun. Music game's note hampers imaginary beats in your head and may throw you off.

Real world example at the example walkthrough section at the end. Note that if your game is keysounded, it may not be possible to add imaginary notes naturally to enhance fun as it will not sound. In that case you can try cutting out awkward beats so it is fun instead.

## Lane control

Which lane would you place the note? You have to be mindful about note density and hand movement. Other than obviously try to balance them out, even if the end product is balanced, not all lanes are equals.

A lane which is at your ring or pinky finger requires more effort to hit than index finger. There is a different weight in each lane. (So "balanced" is not necessary all lanes received the same amount of notes.)

A keyboard game like O2Jam has an awkward pattern called a bracket. If I label all the keys as 123 4 567, then this pattern : \[13\]\[2\]\[13\]\[2\]... is especially hard. Try alternating between first : hit index-ring at the same time, then second : hit only middle finger, then repeat over and over fast, you will know what I mean. In a game like IIDX, staircases are much harder than in O2Jam, because in O2Jam your fingers are already stationed linearly for them. In Pop'n Music, brackets are easier since you use the whole hand instead of fingers, and you can see-saw your wrist, or even use the other hand for help if available.

Beware of accidental patterns formed from your lane decision, like accidental mini-jacks (2 notes on the same lane one after another). For example you place a double/chord for cymbal, then the next note has higher chance to be in the same lane as one of the previous notes. You could do this intentionally for impact, or avoid this to increase flow. If a staircase runs into a cymbal you may be tempted to place a double in a way that it does not form an accidental mini-jack, but this may instead create a pseudo bracket. If there is no way out, you may skip that double instead or change it to a single long note. Get creative and don't be locked in your own rule in your head.

A game which requires physical movement like DDR, 2 jumps from UL to DR is a bit more demanding than 2 jumps from LR to UD, despite both cases no notes are overlapping with the previous one and absolutely no accidental patterns formed. The reason being UL to DR feels more like squatting where you may lose balance to the front or back, but LR to UD has perfectly countering momentum that keeps you steady. Jubeat is one game that didn't use body movement but unexpectedly rely on movements because you cannot station your hand to prepare for all patterns. For example, just the seemingly simple 2 double notes \[3+8\] corner pattern actually require you to twist the arm a bit from the rest position, because your hand can't pivot fast to that posture. Games like Chunithm or SDVX, where even in very difficult song an experienced player could be seen relatively stable and mashing the controller, you can cover most input except for patterns that locks your hand and force the other hand to crossover.

## Pitch relevancy and intuitive patterns

They are patterns that are mostly "agreed" to work. In real world, higher frequency sounds tends to go to the right or up. If your game has a "right" or "up", try to make that go together with the music. For example, if a piano arp that goes up is in the song, you may layout the note as from left to right as opposed to right to left. You may break this rule for pattern variation, but generally pitch relevancy is baked into human's brain already.

About intuitive patterns, if something "repetitive sounding" is coming naturally jackhammer pattern is a direct representation, but also a 2 note trills works as well. Something that sounds like a staircase could be replaced by slightly alternating back and forth staircase hybrid, that is still going from left to right "overall".

## Pattern variations

Test it out well. You will begin learning available variation that are kinda the same meaning wise. For example in DDR, if you previously used Left-Down-Right crossover (if your left foot starts on left, you are required to cross that foot to R button if you want to always alternating foot.) then when that sound comes again, it's mirror Right-Down-Left is the variation you could use, but not Left-Up-Down where there is no crossover and the weight of pattern is different. The player will fail to associate the variant with a prior pattern. Or in O2Jam, if you previously used a straight staircase 1234567 then later you may use something like 1425364, it will fell kinda the same, but with different notes.

But also sometimes repeating the same pattern over and over is more fun than changing the pattern often, so the player could get a feel what they are hitting.

In a genre like Techno for example, being repetitive could represent the song more than varying them because repetitiveness is what defining the genre. In IIDX, there is a term "L1 kick" where songs put kick drum consistently on lane 1, at least at the song's beginning. It helps the player getting into the song as opposed to it being all over the place for the sake of variation. In DDR a song Rising Fire Hawk Challenge chart, if you focus on the down arrow lane you see it meaningfully coming back to the lane most of the time kick drum strikes, it goes very well with a Hardstyle song like this and feel like the kick is coming out from that pad despite being a non-keysounded game.

Music is in a way meaningful repetition with variation that are related with music theories, you can do the same with your notechart. The same reason music do not change its kick drum sound every measure, you can do the same with your notechart.

## Decorations

Recently there are more decoration elements added to the charts. It make the chart more distinct and visually interesting, but it may affect gameplay more or less as well.

### BPM changes

Classically BPM changes could be considered decorations, when the song goes to a break section then the BPM halves accordingly, making the chart looks more "breathtaking". This affects difficulty and tecnicality of the chart as well. Be aware of "slowdown syndrome" where you are always tempted to halves BPM on almost every song because you notice some kind of break in every song. It's a part of composition technique that before chorus, the tension before it should be low enough for the chorus to be powerful. That doesn't mean there should be a slowdown on every song.

### Note speed changes

Some games modify the note speed like they change your speed mod, Pump It Up extensively use this. Well, you can make bouncing charts and it is one of the most common thinking of this feature. But think for yourself if that is excessive or not.

In Taiko no Tatsujin, the "timeline" appears to tie to each notes as oppposed to all notes being run on the same timeline. This can produce bizarre effect like a later coming note appears to "race" faster and catching up or even get ahead of notes that came earlier.

### Environmental changes

Games like SDVX, Ongeki, Arcaea, or Lanota can move lanes, change the shape of lane, or change viewing perspective mid-song. Making it possible to vary play experience without touching notes. It is good to give the note charter more tools to play with more than available lanes.

Be careful when this affects user experience. In touch screen if this moves the touch zone it will be more difficult. In a game like Neon FM where you have a controller that stay still, excessive visual can still be too much and tiring instead of flowing. Do think from time to time that when one enjoy a music (not music game, just listening to music) the happiness do come from just gently bopping head, being in a flow that guides him to the end. You don't have to make the notechart like death trap stage in Japanese game show.

Groove Coaster have its experience based mainly on environmental changes, because there is a unique stage made for each song. Muse Dash has a specific moment when a boss will appear. SDVX has a specific moment when stage visibly changed when the song enter chorus section. This "stage" approach extends the progression of song to not only advance the notechart forward, you can feel the "place" where each note belongs.

### Note arts

Withing the charts, you can use the note objects for decoration as well. These came from the fact that sometimes you don't have to play them or they are lenient enough that wacky shapes didn't affect gameplay too much. You may think about adding them to your game design that it simultaneously create a solid gameplay and interesting note chart. (Do not sacrifice solid gameplay.)

- Long note is the most common target (victim) to create note arts. In O2Jam, sometimes the tail length of long note doesn't represent the lingering sound at all. They are just long for the sake of their look! I personally call some stupid pattern in that game [a "Khene" pattern](https://en.wikipedia.org/wiki/Khene) because it looks like that Thai instrument. Reflec Beat also implemented a special on-off long note in its latest installment that is capable of creating note arts.
- "Rapid notes" that is more lenient in timing or positioning has been gaining popularity. Deemo has golden notes that you can just drag around, so they often make interesting shapes out of them while not affecting difficulty. VOEZ has particle notes that do the same thing. Dynamix's fader red note too.
- A game with fluid lanes (looks non-discrete) like Voez or Arcaea have more liberty to create art, much like latte art where instead of just pouring milk you can pour it anywhere in XY coordinate on the cup's surface. It will not affect the taste much, but more visually pleasing.
- A game with "warning indicator" that aids readability like SDVX (knob warning), Arcaea (air note incoming indicator), Ravon (grid note incoming indicator), Reflec Beat (top note warning), Cross Beats (guiding diagonal lane), can use those for artistic purpose, by programming them to be able to manually specifiable in the chart when should they appear. (As opposed to hard coding it that they must appear `x` beats before the kind of note that is hard to read.)
- In BMS, charter sometimes use the custom measure bar feature just to make it more artistic when you see a lot more bars coming in grabbing your attention, you are not playing them.
- Games with note colors like Stepmania, DDR, or Tonesphere also could intentionally "colorize" the note. There is one period in Stepmania history where charters shift the note very little bit (64th, 192th off) just to make a note green colored without using mini-long note.
- Games with "do not hit" notes like DDR (shock arrow), Chunithm (damage notes), Ongeki (bullets), In The Groove/Stepmania (mines), can use those for artistic purpose. They are not there just for the player to avoid, they should also represent some "sound" in the song that you would rather not want player to play. They maybe damaging if hit, but you can use them where it is unlikely to hit them at all, remember that the player still see them and may have more fun if something in the song goes with it. (Shock notes in DDR are actually designed so you step on the hard metal panel where there is no arrow when it arrives, so you still can keep the flow.)
- It is not uncommon to express something "literally" with notes.
    - Anytime the song says "up" or "raise your hand" you feel the urge put a flick note that literally goes up.
    - Whenever the song says "guruguru" or "spin" the game must try to convey their version of "spin" just so the player notice and chuckled a bit.
    - When the song says "one two" you literally put one and two notes regardless of any other note theories.
    - Games with fluid notes often attempts to "draw image" with notes to flex that they could.
    - In VOEZ version of Freedom Dive the particle notes actually shaped like downwards arrow.
    - In the song ORCA in DDR A20 the chart turns yellow because the theme of DDR A20 is "golden".
    - On any games that licensed Conflict must find some ways to shoot a beam at the chorus.
    - On any games that licensed Brain Power must try to draw the song's lyric or make the screen goes crazy at the chorus.

# Example walkthrough : BLACK JACKAL

![BLACK JACKAL](./images/black-jackal.png)

Let's follow a completed work of other charters so you have an idea what you may have to think while making a chart. I really like this DDR's **BLACK JACKAL Expert** chart, so let's dig into it!

First, please go **listening to just the song** in its original game, DanceRush Stardom : https://www.youtube.com/watch?v=vKOFP_2pWOo.

Think a bit what the chart would look like. After you are done, watch this DDR chart "solution" : (With assist claps) https://www.youtube.com/watch?v=1zYnKhokPE0, (Line out) https://www.youtube.com/watch?v=umL4fDoEU1w

What do you think? I think this chart is really beautiful for several reasons :

- Most of it is "undeniable". At first glance they flow so well and you can't really argue that which part is wrong.
- But in closer inspection, there are many imaginary notes that is however, "perfectly reasonable" when we play it for real. What's going on with our mind? We like inaccurate notes?
- In a first glance you may not notice the "inconsistencies" at all because they flow so well. But when looking carefully the sound that was a jump earlier disappears the next time they come again. This is to enhance the other sound that they want to focus to begin at the beat they want. Technical charters may have their own rigid rules which sound should be which kind of note, but in a way this improvisation and omitting notes is a rule on its own, which requires creativity also.
- The sound they want to chart has the correct leading beat in a natural way. For example there are 2 places that should be charted the same as 16th note, but one of them has leading imaginary 8th and the other just start at 16th. The decision on this requires imagination about fun and appropriateness instead of accuracy and rhythm-elitism.
- If I were to chart without seeing this DDR chart first, my solution will not end up like this. It would be more accurate, more repetitive, and less fun. I admit defeat.

Now let's analyze this chart deeper.

- 0:10 : Right from start, the song is in 8th offbeat. A consistent of **only** offbeat 8th notes are fun on its own and it will be really hype when bass drum came in and you got to play 4th notes next. But 4th is added to bridge into 3 notes series. It make sense because there are psychedelic synth "around" there and when we step it, we no longer feel that this section is just offbeat notes. It even gives enhanced experience from when we just listening to the song without seeing notes. It is great when note chart could do this. They can highlight background sounds.
- 0:13 : Jumps are added because at that part, the pitch goes up highlighting the offbeat and psychedelic synth is overpowered by it, they better stop adding those 4th notes here which they did. The jumps are from one corner to the other, good choice as it would be too hard to use on a more busy section.
- 0:16 : A melody comes into play.
  - One thing to highlight here is the use of freeze note. The melody, musically, are all the same sound with different pitch. But freeze notes here are so good that you can see the melody's personality. If I were to think the same to insert some freeze notes, at combo 36 I would have put a freeze there too but turns out omitting it make the next one stronger. It feels really good and I was stomping the pad so hard on the freeze note as if the notes are pressure sensitive!
  - The usage of jump is very interesting. There is only one of them on a specific note (like at combo 29), but that make it so good. It is not consistent either, if you are more rigid charter the first hold at combo 24 would have to be a jump also because they are kinda the same. No, you can make things different, in a consistent way, so you have define the new "same" on higher level that is better.
  - Even single stream notes has a good thinking. See that sometimes they put 2 same notes in a row? If you are a very elitist charter, you would think you wouldn't put the same lane unless the melody sounds exactly the same pitch. But what do you think about this one? It feels like stepping on the same pad is "very appropriate" to the melody at that point. Note charter can create their own version of musical scale. They can define "stepping 2 times on this arrow, sounds like this and that.". I hope you get it.
  - Combo 37 is an imaginary note considering the melody. However strictly speaking there are other drum sound at that point too and instead of feeling weird, it is better than omitting.
  - Combo 46 47 48 is a 16th triplet, but the melody doesn't have 16th. This works because it enhances consistency with the previous melody that did have 16th.
  - Combo 50 that leads to the new measure has a sound that is more rapid than 16th and more jarring, but most of the time a consistent 16th is more fun to play, especially this early in the song. (You maybe able to get away with more technical charting towards the end of song. But not in a dance game where keeping your heart going steadily is the fun factor.)
- 0:23 : Of course the most accurate to the new rising snare sounds here would be a single lane of repeating notes, that's not fun obviously. You may vary the notes, but how? An example here, you can add 2 consecutive same lane notes periodically to show the "repeating sprit" while still varying lanes, getting the best of both worlds.
- 0:26 : To accurately step this would be a big stream of 16th, but you can keep that for the latter half by omitting some of them first then introduce the full version better. Note that Pump It Up charters would step it literally as all 16th, it depends on style as well. Personally, I like the DDR way that it represent the raise in tension better even though omitting notes at first is technically inaccurate. Notice that the sound is rising in pitch, the rising of difficulty of notes can reflect this aspect of the song too. If you chart them all as 16th, it may feel more linear and not representing the raise in hype as much.
- 0:29 : Here comes the juicy verse of the song.
  - Combo 96 is silent. To accurately step this, it would be yellow-yellow-blue-red. The first blue is not there. But adding it greatly make you go nori-nori! You can try removing it in your mind and play it. It's annoying to wait just a bit more for that first 16th, right? The key to take away is that the first beat after period of lack of notes, may need some help. Adding imaginary note adds to the context and may **enhance or dilute** the real one that comes next. In this case, I think it enhances the real note.
  - Combo 100 is an another creative freeze note. The sound didn't suggest any freeze note, yet when I see and play it, I think it is a good one. It make the "cap" at combo 101 better, I step on it while bopping my head harder because of the seemingly random freeze before it.
  - Combo 102 is a single jump that I love so much. It is just a simple kick but they put a jump here. It make this kick so damn tighter, and very appropriate that this section is devoid of background sounds, the focus on this kick is insane that putting a jump here is really good.
  - Combo 103 this time this blue note is **not** silent. You see that putting an imaginary note to the one at combo 96 connects better to this one and you can sort of relate your previously kept flow in your heartbeat to this real one.
  - Just a bit before combo 106, this is the place that *should* have the hype kick as a jump I mentioned earlier. But it is not here anymore, because the main course is coming. 3 consecutive synth sound make its first appearance here, it is better to show them off fully, by not even prepending/handicappting them with leading blue note. Let them begin with yellow 16th note, accurately, this time. This is where choosing to chart accurately pays off. And why it works? Because before you didn't chart accurately **yet**, you keep the accurateness to unleash on this one further enhancing the pattern. In the quest for accuracy to be fun, you may need to chart inaccurately or omitting something first. The same theory as why the tension of the song should be in the chorus, and the verse can't be more epic than chorus or else the chorus would lose its charm.
  - Combo 127 this is the only one of this pattern that is not a gallop. Gallop is when blue-yellow-pause-yellow-blue and the yellow notes are on the same lane, connecting it make you feel like riding a horse. This one is questionably not a gallop though all other in this section are. It maybe an oversight and rule-breaking, but I think making the repetitiveness less obvious might also be a good idea. Though I maybe reading in too much here. But the most important of all, it was fine to play.
- 1:01 : This one is a common technique, you should resist the urge to overchart at pre-chorus or break section. Just listening to the song while doing nothing is fun too, if you forgot why you listen to music. And often this kind of section is perfect for that. Also it is challenging too as you must keep the beat while having nothing to play. So you don't hit Greats in the next few notes. If this song has a more difficult chart, I doubt adding difficulty to this section will do any good either. You could say bland long notes you see here is the most difficult this section could get while being fun. And you should strive for this always.
- 1:09 : Between combo 271 and 272 here I would add one more 8th note, but turns out this omitting is really fun. Again I admit defeat of my inferior idea.
- 1:11 : Combo 278 blue arrow here is silent, and the next one is not an awkward 16th but a solid red 4th. Why is this 8th doing here? What is a thinking behind this? The answer is because the previous jump ends on 8th, a **distance** from 8th to 8th is better for your rhythm in your body than a longer 8th to 4th that is more accurate to the song. You see you cannot look at just rhythm values/note color of 4th or 8th. If the entire song is in offbeat 8th, then that is your new 4th. Music is a meaningful relationship as time goes on, and the real meaning of rhythm here is the time between a lack of sound.
- 1:20 : This is the same as in the first section where the charter seldomly put 2 consecutive same lane arrow to highlight the repeating snare sound, but it was changed to more simple 8th stream here. It maybe simply an arbitrary choice, but critically thinking I think it helps as this is just before the chorus, a more relaxed and consistent pattern is better. More reason that 2 consecutive arrow pattern is not here anymore is because at that time at the beginning, they were **just introduced**. This is the same idea as that 3-synth that has the yellow arrow leading it because they were just introduced. It is also a common technique to highlight a new element, but later bring them to background.
- 1:23 : Now the charter didn't hold back and chart a full 16th stream here. Doing it less in the beginning pays off here as it signifies that the chorus is more powerful than the beginning as the song should be.
- 1:26 : The chorus of the song. Contrary to popular belief, the chorus is not meant to be the hardest section, but meant to be the most memorable and "looked forward to" section of the song. And a common theme in the chorus especially in songs that have no vocal, is that **consistency is key** so you can nori-nori. They chart it like this to fit the song's genre. There are a lot of yellow 16th notes and blue 8th notes that goes to nothing, connecting any possible "holes" in this chorus section so it feels just like when you listen to the song purely, you can "just have fun" without much technicality. (But the chart is not easy per se, it is hard and packed in a not so tricky way.)
- 1:51 : The stream doesn't have any backing rapid sound behind it, but forgiven as it is to serve as a final fortress before the song ends. It offset the non-technical but fun chorus part earlier. If it ends just like that after too much consistency, the player may not be left with satisfied feeling. In normal games at the end of stage you would have a boss, in Left 4 Dead at the end of the stage is hype and made you want to replay it again, this is the same idea. These imaginary notes **will be forgiven**, trust me.

There you go! Try to think of your chart this way and your player may share the same feeling as you, and you maybe even able to silence those elitist rhythm polices out there with pure fun.