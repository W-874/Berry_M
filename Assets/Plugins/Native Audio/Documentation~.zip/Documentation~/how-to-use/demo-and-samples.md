# Demo and Samples

Samples are inside Unity which you can inspect and see how everything connects, which requires a purchase of Native Audio since it is included inside the package. Demo is the same as Samples but is a **build** so you can download try even without purchasing Native Audio.

Available platforms for demo builds are : Android (IL2CPP APK) and iOS (Xcode Project), all supported platforms available in Native Audio.

## Getting samples

Follow instructions in [Getting Started/Installing](./installing.md) until you unzip `Samples~.zip`. There is a folder inside `Samples~` named `NativeAudioSamples`. You can copy it out of `Samples~` into your game so Unity starts importing it.

If you keep going and make it full-UPM, Samples can be imported by pressing "Import" button in Package Manager window while inspecting Native Audio entry.

## Structure

![Sample structure](../images/demo-folder.png)

There are **3 scenes** which **connects to each other** by pressing button to go to the next. Building these scenes should include all 3 and make sure `NativeAudioDemo-TestPlayer` is the first one.

Everything are wrapped in an Assembly Definition (`.asmdef`) named `E7.NativeAudio.Samples` and is referencing `E7.NativeAudio`, just like how your game would.

You can ignore everything in `Debugging` folder. They are only for my personal development purpose. But I left them in just in case it might be interesting to you, or that I can sometimes request users that are having problems to test the plugin using them on the phones that I don't have.

### A note on `StreamingAssets`

Before building, you need to put an `AudioClip` named `NativeAudioDemoSA` inside the folder named `#Put the content in StreamingAssets` into your `StreamingAssets` manually. Because one of the feature in `NativeAudioDemo-TestPlayer` demo scene involves loading from `StreamingAssets`.

## Download Demo

These pre-built demo are for those who have not purchased Native Audio yet, or you simply want an APK to feed into an Android phone you want to make sure Native Audio really works or not. Xcode project can also run some test on iPhone devices if you have developer license and a macOS.

- **Android (IL2CPP APK)** : https://exceed7.com/dl/native-audio-demo-android
- **iOS (Xcode Project)** : https://exceed7.com/dl/native-audio-demo-ios

If you had purchased Native Audio, you can access Samples in the package instead so you can also learn the C# code.

## Scenes

You can go to the next scene by pressing the button on the bottom right, given that you included all of them in the build. The last scene go back to the first one in circle.

### Test Player

![Test Player demo](../images/demo-test-player.png)

This demo has most public APIs you can call to `NativeAudio` available as buttons. The plugin starts with `static` call to initialize and load, and move to instance-based call on the returned `NativeAudioPointer`. The load button will remember the **latest** returned `NativeAudioPointer` that would receive the play/stop/unload calls.

One of the most interesting thing in this demo is that the bottom most button call `PlayOneShot` on Unity's original `AudioSource`. It makes this demo the best evidence how much Native Audio is better than Unity. (And also more inconvenient and feature-deprived.)

### Stress Test

![Stress Test demo](../images/demo-stress-test.png)

In long past (2017-2018?), I once worked with one customer that experienced lag on every play only on some specific Chinese Android phone. This scene plays the audio rapidly in order to make sure it doesn't lag even under extreme situation. Look at the spinning stick to determine if the frame rate dropped.

The "slower" button was made because some customers claimed than sometimes it wouldn't play when called play, this button allows you to keep track whether it refuse to play from time to time or not.

### Custom Index

![Custom Index demo](../images/demo-custom-index.png)

Native Audio cannot mix audio, but can gain back polyphony by sending audio to different "native source index" instead so it sounds like we can have overlapping audio.

This demo highlights this fake-polyphonic feature by having long looping audio on index 0, and shorter audio that is scripted to **avoid** the native source index that the long one is playing on, by alternating between index 1 and 2.

The fact that long audio doesn't stop no matter what proves that if you can manage native sources wisely you can mitigate the unmixed aspect of Native Audio. Moreover, if you play the shorter audio 3 times in succession it would cut off the oldest instance because we only got index 1 and 2 to cycle around, highlighting the challenge and strategy of managing native sources.