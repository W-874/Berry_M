# Attributions

Native Audio is powered by **`libsamplerate` (Secret Rabbit Code) by Erik de Castro Lopo**. (http://www.mega-nerd.com/SRC/) It is to fit `AudioClip` with mismatched import settings to the device's native rate at runtime as explained in [Ways around latency](../theories/ways-around-latency.md).

Sampling is a huge topic and I cannot possibly get right by myself with acceptable quality. So `libsamplerate` can help on this with very good quality resampling method.

(If you are interested in learning more about audio resampling, I recommend this paper! : https://ccrma.stanford.edu/~jos/resample/ )

The license is 2-clause BSD which is really permissive and requires you only to put the attribution somewhere in the game. (You will do the 2nd clause, the file `LICENSE.md` included in your purchase is doing the 1st clause.)

To do this, check `LICENSE.md` included in the package to find a copy-pastable text.